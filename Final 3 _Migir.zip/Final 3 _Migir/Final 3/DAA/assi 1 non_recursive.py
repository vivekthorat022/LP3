def fibonacci_series(n):
    if n <= 0:
        return 
    elif n == 1:
        return [0]
    
    fib = [0, 1]  # Initialize the first two Fibonacci numbers
    for i in range(2, n):
        fib.append(fib[i - 1] + fib[i - 2])  # Append the sum of the last two numbers
    return fib

# Take input from the user
n = int(input("Enter the number of Fibonacci terms to display: "))
print("Fibonacci series up to {n} terms:", fibonacci_series(n))
